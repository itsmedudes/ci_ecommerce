<?php

class  Dashboard extends CI_Model{
    function getTotalEarnings(){
       return  $this->db->select_sum('total_amount')
               ->get('orders')->result();
    }
    function getTotalNoOfEntry(){
        return $this->db->count_all("orders");
    }
}

